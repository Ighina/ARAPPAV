# ARAPPAV Self-Play Experiment Report — `algebra_evolve`

## 1. Configuration

| Setting | Value |
|---|---|
| Source dataset | `hendrycks` |
| Topics / category | `algebra` (single topic), `per_topic = 300` |
| Problems file | none (`null`) — sampled from the source |
| Rounds | 10 (round 0 … round 9) |
| Episodes per round | 8 (80 episodes total) |
| `k` (errors injected per episode) | 3 |
| Initialization | `cold` start |
| Freeze configuration | `none` — both perturber and verifier updated every round |
| Context passed to agents | yes (`no_context = false`, `rich_context = false`) |
| Rollout model | `claude-haiku-4-5`, backend `claude-code` |
| Updater model | `claude-opus-5` |
| Update mode | `evolve`, `accept_on_validation = true`, `validation_n = 12` |
| Seed | 42 |
| Taxonomy | fixed (`taxonomy_free = false`) |
| Rollout root | `data/skill_rollouts/algebra_evolve` |
| Skills root | `.claude/skills`, prefixes `algev_perturb` / `algev_verify` |
| Timeout / max tokens | 900 s / 16000 |
| Retries | `infra_retries = 2`, `retry_format = 1` |
| Resume | enabled |
| ProcessBench | **disabled** (`processbench_enabled = false`) |

## 2. Round-by-round table

| round | perturb policy | verify policy | format-valid | mean r_P | mean r_V | recall | precision | units/ep | penalties | ProcessBench |
|---|---|---|---|---|---|---|---|---|---|---|
| 0 | algev_perturb-v1 | algev_verify-v1 | 1.0 | 0.2708 | 0.8083 | 0.7292 | 1.0 | 2.375 | 0 | disabled |
| 1 | algev_perturb-v2 | algev_verify-v2 | 1.0 | 0.0833 | 0.875 | 0.8542 | 0.9167 | 2.0 | 0 | disabled |
| 2 | algev_perturb-v3 | algev_verify-v3 | 1.0 | 0.0625 | 0.9271 | 0.9375 | 0.95 | 2.25 | 0 | disabled |
| 3 | algev_perturb-v4 | algev_verify-v4 | 1.0 | 0.2708 | 0.7958 | 0.7292 | 0.9375 | 2.5 | 0 | disabled |
| 4 | algev_perturb-v5 | algev_verify-v5 | 1.0 | -0.5208 | 0.85 | 0.8333 | 0.9167 | 2.0 | -5.0 | disabled |
| 5 | algev_perturb-v6 | algev_verify-v6 | 1.0 | 0.125 | 0.85 | 0.8125 | 0.9583 | 2.25 | 0 | disabled |
| 6 | algev_perturb-v7 | algev_verify-v7 | 1.0 | 0.1042 | 0.8646 | 0.8958 | 0.8458 | 2.125 | 0 | disabled |
| 7 | algev_perturb-v8 | algev_verify-v8 | 1.0 | 0.3333 | 0.7625 | 0.6667 | 0.9583 | 2.5 | 0 | disabled |
| 8 | algev_perturb-v9 | algev_verify-v9 | 1.0 | 0.1042 | 0.7048 | 0.7708 | 0.6875 | 2.25 | 0 | disabled |
| 9 | algev_perturb-v10 | algev_verify-v10 | 1.0 | -0.5 | 0.8333 | 0.8125 | 0.8958 | 2.375 | -5.0 | disabled |

## 3. Policy evolution

**Perturber** — cold-started at `algev_perturb-v1` in round 0 and incremented by exactly one version in every subsequent round: v1 (r0), v2 (r1), v3 (r2), v4 (r3), v5 (r4), v6 (r5), v7 (r6), v8 (r7), v9 (r8), v10 (r9). All 9 inter-round transitions produced a new version, so every round updated the perturber and none was frozen. This is consistent with `freeze = "none"`; `accept_on_validation = true` with `validation_n = 12` was in force, but the run data does not record per-round accept/reject decisions or validation scores, so the report cannot say whether any candidate was rejected and re-proposed — only that a new version number was in place each round.

**Verifier** — identical pattern: cold-started at `algev_verify-v1` (r0) and incremented each round to `algev_verify-v10` (r9). No round reused the previous version; no side was frozen at any point.

Neither side was ever held fixed, so **no round isolates one policy's effect from the other's**. Every metric movement below is a joint move of a changed perturber against a changed verifier.

## 4. Rewards and penalties by round

| round | mean r_P (Δ) | mean r_V (Δ) | recall (Δ) | precision (Δ) | units/ep (Δ) | duplicate | spam | repetition | phantom |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 0.2708 (—) | 0.8083 (—) | 0.7292 (—) | 1.0 (—) | 2.375 (—) | 0 | 0 | 0 | 0 |
| 1 | 0.0833 (↓0.1875) | 0.8750 (↑0.0667) | 0.8542 (↑0.1250) | 0.9167 (↓0.0833) | 2.000 (↓0.375) | 0 | 0 | 0 | 0 |
| 2 | 0.0625 (↓0.0208) | 0.9271 (↑0.0521) | 0.9375 (↑0.0833) | 0.9500 (↑0.0333) | 2.250 (↑0.250) | 0 | 0 | 0 | 0 |
| 3 | 0.2708 (↑0.2083) | 0.7958 (↓0.1313) | 0.7292 (↓0.2083) | 0.9375 (↓0.0125) | 2.500 (↑0.250) | 0 | 0 | 0 | 0 |
| 4 | −0.5208 (↓0.7916) | 0.8500 (↑0.0542) | 0.8333 (↑0.1041) | 0.9167 (↓0.0208) | 2.000 (↓0.500) | **−5.0** | 0 | 0 | 0 |
| 5 | 0.1250 (↑0.6458) | 0.8500 (0.0000) | 0.8125 (↓0.0208) | 0.9583 (↑0.0416) | 2.250 (↑0.250) | 0 | 0 | 0 | 0 |
| 6 | 0.1042 (↓0.0208) | 0.8646 (↑0.0146) | 0.8958 (↑0.0833) | 0.8458 (↓0.1125) | 2.125 (↓0.125) | 0 | 0 | 0 | 0 |
| 7 | 0.3333 (↑0.2291) | 0.7625 (↓0.1021) | 0.6667 (↓0.2291) | 0.9583 (↑0.1125) | 2.500 (↑0.375) | 0 | 0 | 0 | 0 |
| 8 | 0.1042 (↓0.2291) | 0.7048 (↓0.0577) | 0.7708 (↑0.1041) | 0.6875 (↓0.2708) | 2.250 (↓0.250) | 0 | 0 | 0 | 0 |
| 9 | −0.5000 (↓0.6042) | 0.8333 (↑0.1285) | 0.8125 (↑0.0417) | 0.8958 (↑0.2083) | 2.375 (↑0.125) | **−5.0** | 0 | 0 | 0 |

Observations, stated at the strength 8 episodes per round supports:

- **Perturber reward oscillates; it does not trend.** Ignoring the two penalised rounds, r_P ranges 0.0625–0.3333 with no monotone segment longer than two rounds. Its best round (7, 0.3333) and joint-worst unpenalised rounds (2, 0.0625) are 5 rounds apart in the wrong direction for a learning story.
- **`mean_perturber_reward` equals `mean_perturber_reward_valid_only` in all 10 rounds**, which follows from format validity being 1.0 everywhere — no episodes were excluded.
- **The only penalty ever triggered is the duplicate penalty**, at exactly −5.0 in rounds 4 and 9 and 0 in the other eight. Spam, repetition and phantom penalties are 0 in all 10 rounds. Both negative r_P values are entirely attributable to those duplicate penalties: r_P is positive in every round where the penalty is 0.
- **Verifier reward stays in a narrow band**, 0.7048 (r8) to 0.9271 (r2), a spread of ~0.22 across the run, with no direction. Round 0's r_V (0.8083) and round 9's (0.8333) differ by 0.025 — within the round-to-round noise seen throughout.
- **Recall and precision move roughly in opposition.** Round 0 has perfect precision (1.0) with the second-lowest recall (0.7292); round 2 achieves the run's best of both (0.9375 / 0.95); round 7 posts high precision (0.9583) with the run's lowest recall (0.6667); round 8 posts the run's lowest precision (0.6875). The single largest precision drop is r6→r8 (0.9583 → 0.6875, −0.2708 from r7 to r8).
- **Units per episode never reaches k = 3** in any round; it ranges 2.0–2.5 against `k = 3`. See §6 on unit collapse.

## 5. ProcessBench

**ProcessBench was not run.** `processbench_enabled` is `false` in the run configuration, and every one of the 10 round records carries `"enabled": false` with the note "ProcessBench was not run for this round." The configured-but-unused settings were `processbench_per_subset = 5`, `processbench_root = "data/skill_evals"`, `processbench_seed = 0`.

Consequently **no external-validity claim can be made about either policy.** Every number in this report is measured inside the self-play loop, where the perturber that creates the errors and the verifier that must find them are co-evolving against each other. Verifier recall of 0.9375 in round 2 says the verifier found errors that *that* round's perturber injected; it says nothing about performance on human-annotated errors or on any held-out benchmark. In particular, the joint reward structure means a rising verifier reward could reflect a weakening perturber rather than a strengthening verifier, and nothing in this run distinguishes the two.

## 6. Findings by round

Every round: 8/8 episodes format-valid, **zero format failures across all 80 episodes**. Every round also shows unit collapse — episodes with fewer than `k = 3` distinct error units.

**Round 0** (perturb-v1 / verify-v1) — 24 injected errors, 15 detected, 9 missed. Perfect precision (1.0): **zero false positives**, the only such round. Weakest type: `wrong_operation` 5/10 (0.50); also `wrong_sequence_term` 3/5 (0.60), `negative_number_error` 2/3, `operand_swap` 0/1. Fully detected (small n): `incomplete_solution` 1/1, `additive_thinking` 2/2, `proportional_reasoning_error` 1/1, `variable_misconception` 1/1. Unit collapse in 5 episodes (ep02–ep05, ep07), all at 2 units vs k=3. Notably, misses cluster on the *later* injected errors — 8 of 9 undetected are err_002 or err_003.

**Round 1** (v2) — 24 injected, 16 detected, 8 missed. New types appear: `decimal_magnitude` 2/2, `wrong_fraction` 3/3, `whole_number_bias` 0/1. Weak: `wrong_operation` 3/6 (0.50), `negative_number_error` 1/2, `variable_misconception` 1/2; `wrong_sequence_term` 5/7 (0.714). First false positives of the run: 2, both in ep02, both keying off a mis-read of `$t^2 - 50$` vs `$t^2 - 49$` — the verifier flagged the perturbed premise itself as an error. Unit collapse in 5 episodes, three of them collapsing all the way to **1 unit** (ep00, ep04, ep06) — the only round with 1-unit episodes besides r4.

**Round 2** (v3) — the run's strongest verifier round: 24 injected, 21 detected (recall 0.9375, r_V 0.9271). Nine of ten error types detected at rate 1.0, including `wrong_operation` 7/7 — a type at 0.50 in both prior rounds. The two failures: `operand_swap` 2/3 and `decimal_magnitude` **0/2** (a type that was 2/2 one round earlier). All 3 misses sit in ep01 and ep05. Two false positives, both in ep06, both disputing a boxed final answer (34.4 / 34 vs a claimed correct 35). Unit collapse in 6 of 8 episodes, all at 2 units.

**Round 3** (v4) — 24 injected, 15 detected, 9 missed; recall falls to 0.7292, back to the round-0 level. `negative_number_error` 4/4 and `wrong_sequence_term` 1/1 hold; `operand_swap` 3/4 (0.75); `wrong_operation` drops to 6/9 (0.667) after 7/7. Three types go to zero: `whole_number_bias` 0/1, `wrong_fraction` 0/1, `proportional_reasoning_error` 0/1; `inversion_error` 1/3 (0.333) — a type first seen this round. One false positive (ep00, an `i`-arithmetic FOIL expansion). Units/ep peaks at 2.5; unit collapse in 4 episodes.

**Round 4** (v5) — the first **duplicate penalty (−5.0)**, driving r_P to −0.5208, the run's minimum. 24 injected, 17 detected, 7 missed; verifier metrics are unremarkable (r_V 0.85, recall 0.8333). Type detection: `wrong_fraction` 4/5, `negative_number_error` 3/4, `whole_number_bias` 2/3, `wrong_operation` 6/10 (0.60), `inverse_operation_error` 1/1, `operand_swap` 1/1. Two false positives (ep02 `\sqrt{108}` vs `\sqrt{109}`; ep04 a fraction subtraction). **Unit collapse in 7 of 8 episodes** — the worst of the run — including one 1-unit episode (ep06); units/ep 2.0. The co-occurrence of maximal collapse and the duplicate penalty is consistent with the perturber emitting near-identical error units, though the run data records the penalty total only and not which episodes incurred it.

**Round 5** (v6) — 24 injected, 15 detected, 9 missed. `wrong_operation` is the dominant injected type at 13 of 24 injections and detects at only 7/13 (0.538). Two novel types appear and both go undetected: `irrelevant_feature` 0/1 and `angle_misconception` 0/1 (both in ep05). Everything else with n≤4 detects at 0.75–1.0. One false positive (ep02, a completed-square constant 25 vs 16). Precision 0.9583. Unit collapse in 6 episodes, all at 2.

**Round 6** (v7) — 24 injected, 17 detected, 7 missed; recall 0.8958 but precision drops to 0.8458 on **4 false positives** — the second-highest count of the run — spread over ep01, ep04 and ep06 (ep06 twice, both disputing the same `\#(15)` span). `wrong_operation` 7/11 (0.636), `whole_number_bias` 3/4, `wrong_sequence_term` 1/2, `wrong_fraction` 0/1; `inverse_operation_error` 2/2, `incomplete_solution` 2/2, `denominator_only` 1/1, `additive_thinking` 1/1. **All 7 misses are err_003** — every episode's third injected error, and no earlier one, survived. Unit collapse in 7 of 8 episodes, all at 2.

**Round 7** (v8) — the run's **worst recall (0.6667)** and best perturber round (r_P 0.3333, no penalty). 24 injected, 13 detected, 11 missed — the most misses of any round. Eleven distinct error types were injected, the most of the run, and detection is at or below 0.556 for the five most-injected: `wrong_operation` 5/9, `denominator_only` 1/2, `variable_misconception` 1/2, `wrong_sequence_term` 1/2, `operand_swap` 1/2, `negative_number_error` 1/2; `inversion_error` 0/1 and `decimal_magnitude` 0/1 survive entirely. Precision stays high (0.9583) on a single false positive (ep00, a root-difference off by a factor of 2). Units/ep 2.5 (tied highest); unit collapse in only 4 episodes — the joint-lowest of the run.

**Round 8** (v9) — the run's **worst verifier round on both r_V (0.7048) and precision (0.6875)**, on **5 false positives** — the highest count — in ep01, ep03, ep04, ep05, ep06. 24 injected, 14 detected, 10 missed. `wrong_operation` again dominates injection (13/24) and detects at 7/13 (0.538); `proportional_reasoning_error` 0/1 and `incomplete_solution` 0/1 survive; `wrong_fraction` 1/2; `denominator_only` 2/3. ep03 is a total verifier failure — all three of its injected errors undetected, and it also carries a false positive. Eight of ten misses are err_003. Unit collapse in 6 episodes, all at 2.

**Round 9** (v10) — the second **duplicate penalty (−5.0)**, r_P −0.5. 24 injected, 16 detected, 8 missed; r_V recovers to 0.8333, precision 0.8958 on 2 false positives (ep00 a y-intercept, ep05 a double-zero substitution). `wrong_operation` detects at 6/7 (0.857), its best rate since round 2; `negative_number_error` 4/6 (0.667) despite being the most-injected type; `whole_number_bias` 0/1, `incomplete_solution` 1/2, `wrong_sequence_term` 1/2. Unit collapse in 5 episodes, all at 2 units; units/ep 2.375.

**Cross-round patterns visible in the findings:**

- **`wrong_operation` is both the most-injected and the most-survived type.** Injections by round: 10, 6, 7, 9, 10, 13, 11, 9, 13, 7 (95 total across 10 rounds), with detection rates 0.50, 0.50, 1.00, 0.667, 0.60, 0.538, 0.636, 0.556, 0.538, 0.857. Round 2's 7/7 is the outlier, not the norm.
- **Errors injected late in an episode survive disproportionately.** In round 6 all 7 misses are `err_003`; in round 8, 8 of 10; in round 0, 8 of 9 are err_002/err_003. This holds across otherwise dissimilar rounds.
- **Rare error types are unreliable in both directions.** `decimal_magnitude` goes 2/2 (r1) → 0/2 (r2) → 0/1 (r7). `whole_number_bias` goes 0/1 (r1) → 1/1 (r2) → 0/1 (r3) → 2/3 (r4) → 3/4 (r6) → 1/1 (r7) → 0/1 (r9). At n≤4 injections per round these rates carry essentially no information individually.
- **Unit collapse is universal.** Every one of the 10 rounds has at least 4 collapsed episodes, and 53 of 80 episodes are recorded as collapsed, all with `k = 3` and 1–2 actual error units. `mean_units_per_episode` never reaches 3.0 in any round. The perturber never reliably produced three genuinely distinct error units.
- **False positives rose over the run but not monotonically:** 0, 2, 2, 1, 2, 1, 4, 1, 5, 2 across rounds 0–9. The two worst rounds (6 and 8) are separated by round 7, which had one.

## 7. Final conclusions

What this run established, at 8 episodes per round and 80 episodes total:

1. **Format compliance is solved, and robustly so.** 80/80 episodes were format-valid across 10 rounds and 10 distinct policy versions on each side. This is the one result the sample size fully supports.

2. **No learning trend is demonstrable for either side.** Verifier reward starts at 0.8083, peaks at 0.9271 in round 2, bottoms at 0.7048 in round 8, and ends at 0.8333 — a net change of +0.025 over 10 rounds, with excursions in both directions several times that size. Perturber reward (excluding the two penalised rounds) ends at roughly where it began. With 8 episodes and ~24 injected errors per round, a recall difference of 0.08 is one or two errors; the observed round-to-round swings are of that order and cannot be separated from sampling noise. Round 2's strong result (recall 0.9375, precision 0.95) rests on 8 episodes and was not reproduced in any of the 7 rounds that followed.

3. **Because nothing was ever frozen, no round attributes a change to one policy.** All 10 rounds ran a fresh perturber against a fresh verifier. A recall drop such as r2→r3 (0.9375 → 0.7292) is equally consistent with a better perturber and a worse verifier, and this run cannot distinguish them.

4. **The perturber failed to hit `k = 3` in any round.** Units per episode averaged 2.0–2.5 against a target of 3, with 53 of 80 episodes explicitly flagged as collapsed. Whatever else the run measured, it measured a task somewhat easier than the one configured.

5. **The recall/precision trade-off is visible but unresolved.** The run's highest-precision round (0, at 1.0) has near-lowest recall; the highest-recall round (2, 0.9375) is the only one that got both above 0.93; and rounds 6 and 8 bought recall with 4 and 5 false positives respectively. Over 10 rounds the evolution did not find a version that reliably held both.

6. **Two of ten rounds hit the duplicate penalty and nothing else ever penalised.** Rounds 4 and 9 each incurred exactly −5.0 duplicate penalty; spam, repetition and phantom penalties were 0 in all 80 episodes. The duplicate failure mode recurred five rounds apart rather than being eliminated after its first appearance.

7. **None of this generalises beyond the loop.** With ProcessBench disabled there is no external measurement of either policy at any round.

## 8. Anomalies and failures

- **ProcessBench never ran** (all 10 rounds), despite `processbench_per_subset`, `processbench_root` and `processbench_seed` being configured. This is the largest gap in the run: no held-out evaluation exists for any of the 10 verifier versions.
- **Duplicate penalty of exactly −5.0 in rounds 4 and 9**, and only there. The value is identical in both rounds, and the run data records only the round total — not which episodes or how many duplicate units triggered it — so the per-episode cause is not recoverable from this JSON.
- **Systematic unit collapse: 53 of 80 episodes** produced fewer than `k = 3` error units. Four episodes collapsed to a single unit (round 1: ep00, ep04, ep06; round 4: ep06). Round 4 had 7 of 8 episodes collapsed. `mean_units_per_episode` was below 3.0 in every round, so the configured difficulty was never reached.
- **Detection-rate reversals on the same error type between consecutive rounds**, most starkly `decimal_magnitude` 2/2 in round 1 → 0/2 in round 2, and `wrong_operation` 7/7 in round 2 → 6/9 in round 3. With n ≤ 13 injections per type per round these are not stable measurements and should not be read as capability changes.
- **Round 8 is the outlier round on verifier quality**: precision 0.6875 and 5 false positives, both run worsts, with r_V 0.7048. Episode ep03 in that round had all three injected errors undetected *and* contributed a false positive.
- **Two false positives in round 1 (ep02) flag the perturbation premise itself** — the verifier objected that the problem asks to factor `$t^2-49$`, not `$t^2-50$`. Whether that is a genuine verifier error or a scoring-boundary artifact (the verifier correctly noticing the perturbed premise but being scored against ground-truth spans elsewhere) is not decidable from this JSON.
- **Multiple false positives cite the same span twice in one episode** (round 6 ep06: two separate `\#(15)` claims; round 2 ep06: `$\boxed{34.4}$` and `$\boxed{34}$`). Both were counted as distinct false positives.
- **At least two false-positive explanations are truncated mid-sentence** in the record (round 7 ep00, ending "is missing the factor"; round 8 ep03, ending "which simplifies to $\frac{9"), suggesting a length cap on the stored explanation field.
- **No format-invalid episodes, no recorded agent errors, no empty policies, no frozen sides** — `format_failures` is empty in all 10 rounds, and every round has a distinct, populated perturb and verify policy version.
- **Not recorded in the supplied data**, and therefore not reported: per-round validation scores or accept/reject decisions under `accept_on_validation`, wall-clock or token cost, per-episode reward decompositions, and which specific episodes triggered the duplicate penalty.
