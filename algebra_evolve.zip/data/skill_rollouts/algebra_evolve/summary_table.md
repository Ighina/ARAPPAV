| round | perturb policy | verify policy | format-valid | mean r_P | mean r_V | recall | precision | units/ep | penalties | ProcessBench |
|---|---|---|---|---|---|---|---|---|---|---|
| 0 | algev_perturb-v1 | algev_verify-v1 | 1.0 | 0.2708 | 0.8083 | 0.7292 | 1.0 | 2.375 | 0 | disabled |
| 1 | algev_perturb-v2 | algev_verify-v2 | 1.0 | 0.0833 | 0.875 | 0.8542 | 0.9167 | 2.0 | 0 | disabled |
| 2 | algev_perturb-v3 | algev_verify-v3 | 1.0 | 0.0625 | 0.9271 | 0.9375 | 0.95 | 2.25 | 0 | disabled |
| 3 | algev_perturb-v4 | algev_verify-v4 | 1.0 | 0.2708 | 0.7958 | 0.7292 | 0.9375 | 2.5 | 0 | disabled |
| 4 | algev_perturb-v5 | algev_verify-v5 | 1.0 | -0.5208 | 0.85 | 0.8333 | 0.9167 | 2.0 | -5.0 | disabled |
| 5 | algev_perturb-v6 | algev_verify-v6 | 1.0 | 0.125 | 0.85 | 0.8125 | 0.9583 | 2.25 | 0 | disabled |
| 6 | algev_perturb-v7 | algev_verify-v7 | 1.0 | 0.1042 | 0.8646 | 0.8958 | 0.8458 | 2.125 | 0 | disabled |
| 7 | algev_perturb-v8 | algev_verify-v8 | 1.0 | 0.3333 | 0.7625 | 0.6667 | 0.9583 | 2.5 | 0 | disabled |
| 8 | algev_perturb-v9 | algev_verify-v9 | 1.0 | 0.1042 | 0.7048 | 0.7708 | 0.6875 | 2.25 | 0 | disabled |
| 9 | algev_perturb-v10 | algev_verify-v10 | 1.0 | -0.5 | 0.8333 | 0.8125 | 0.8958 | 2.375 | -5.0 | disabled |
